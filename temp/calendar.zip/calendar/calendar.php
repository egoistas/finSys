<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar with AJAX</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        #calendar {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .days {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
        }

        .day {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }

        .day:hover {
            background-color: #f0f0f0;
            cursor: pointer;
        }

        #event-details {
            margin-top: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
    </style>
</head>
<body>
    <div id="calendar"></div>
    <div id="event-details"></div>

    <script>
        function generateCalendar(year, month) {
            const calendar = document.getElementById('calendar');
            const date = new Date(year, month);
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const firstDayIndex = date.getDay();
            const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

            calendar.innerHTML = `
                <h2>${monthNames[month]} ${year}</h2>
                <div class="days">
                    ${daysOfWeek.map(day => `<div class="day">${day}</div>`).join('')}
                    ${generateDays(daysInMonth, firstDayIndex)}
                </div>
            `;
        }

        function generateDays(daysInMonth, firstDayIndex) {
            let days = '';

            for (let i = 0; i < firstDayIndex; i++) {
                days += `<div class="day"></div>`;
            }

            for (let i = 1; i <= daysInMonth; i++) {
                days += `<div class="day" onclick="getEventData(${i})">${i}</div>`;
            }

            return days;
        }

        function getEventData(day) {
            const year = new Date().getFullYear();
            const month = new Date().getMonth() + 1;
            const date = `${year}-${month}-${day}`;

            fetch('search_listofTasks.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=fetchDateFromCalendar&date=' + date,
            })
            .then(response => response.json())
            .then(data => {
                displayEventData(data);
            })
            .catch(error => {
                console.error('Error fetching event data:', error);
            });
        }

        function displayEventData(data) {
            const eventDetails = document.getElementById('event-details');
            // Display the fetched data in the event-details div
            // You can customize this as per your requirement
            eventDetails.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
        }

        document.addEventListener('DOMContentLoaded', function() {
            const now = new Date();
            generateCalendar(now.getFullYear(), now.getMonth());
        });
    </script>
</body>
</html>
