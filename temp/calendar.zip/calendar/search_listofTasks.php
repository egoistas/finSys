<?php
$searchVariable = $_POST['date'];

require_once('mysqli_connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'fetchDateFromCalendar') {
        $querySearchByDate = "SELECT * FROM public_tender WHERE OFFER_LAST_DATE = ?";
        $findByDatestmt = mysqli_prepare($dbc, $querySearchByDate);
        mysqli_stmt_bind_param($findByDatestmt, 's', $searchVariable);
        mysqli_stmt_execute($findByDatestmt);
        $result = mysqli_stmt_get_result($findByDatestmt);

        if ($result) {
            $rows = array();
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }

            // Send JSON response to the frontend
            header('Content-Type: application/json');
            echo json_encode($rows);
        } else {
            // Send error message in JSON format to the frontend
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Error executing query: ' . mysqli_error($dbc)));
        }
        
        mysqli_stmt_close($findByDatestmt);
        mysqli_close($dbc);
        exit();
    }
}
?>
