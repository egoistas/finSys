<?php
// logic.php

require_once('mysqli_connect.php');

$searchVariable = $_POST['id'];

$querySearchByDate = "SELECT DATE_OF_1ST_DELIVERY, DATE_OF_2ND_DELIVERY, 
DATE_OF_3RD_DELIVERY, DATE_OF_4TH_DELIVERY FROM executive_contract WHERE 
idEXECUTIVE_CONTRACT = ?";
$findByDatestmt = mysqli_prepare($dbc, $querySearchByDate);
mysqli_stmt_bind_param($findByDatestmt, 's', $searchVariable);
mysqli_stmt_execute($findByDatestmt);
$result = mysqli_stmt_get_result($findByDatestmt);

if ($result) {
    $rows = array();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    // Send JSON response to the frontend
    header('Content-Type: application/json');
    echo json_encode($rows);
} else {
    // Send error message in JSON format to the frontend
    header('Content-Type: application/json');
    echo json_encode(array('error' => 'Error executing query: ' . mysqli_error($dbc)));
}

mysqli_stmt_close($findByDatestmt);
mysqli_close($dbc);
exit();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roadmap</title>
    <style>
        /* Add your CSS styles for the roadmap here */
        .roadmap {
            position: relative;
            height: 50px;
            width: 100%;
            background-color: #f2f2f2;
        }

        .checkpoint {
            position: absolute;
            top: 0;
            height: 100%;
            width: 2px;
            background-color: #ccc;
        }

        .checkpoint.completed {
            background-color: green;
        }

        .checkpoint:last-child {
            width: 0;
        }

        .date {
            position: absolute;
            bottom: -20px;
            left: 50%;
            transform: translateX(-50%);
        }

        .progress-bar {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            background-color: blue;
            z-index: -1;
        }
    </style>
</head>
<body>
    <div id="roadmapContainer"></div>

    <script>
        function drawRoadmap(containerId, checkpoints) {
            const container = document.getElementById(containerId);

            if (!container) {
                console.error('Container element not found.');
                return;
            }

            const today = new Date();
            const checkpointsCount = checkpoints.length;

            const roadmapHTML = `
                <div class="roadmap">
                    ${checkpoints.map((checkpoint, index) => {
                        const date = new Date(checkpoint);
                        const progress = index / (checkpointsCount - 1) * 100;
                        const completed = date < today ? 'completed' : '';

                        return `
                            <div class="checkpoint ${completed}" style="left: ${progress}%">
                                <span class="date">${formatDate(date)}</span>
                            </div>
                        `;
                    }).join('')}
                    <div class="progress-bar" style="width: ${getProgress(today, checkpoints)}%"></div>
                </div>
            `;

            container.innerHTML = roadmapHTML;
        }

        function formatDate(date) {
            const options = { month: 'short', day: 'numeric', year: 'numeric' };
            return date.toLocaleDateString('en-US', options);
        }

        function getProgress(today, checkpoints) {
            const checkpointsCount = checkpoints.length;
            let progress = 0;

            for (let i = 0; i < checkpointsCount; i++) {
                const checkpointDate = new Date(checkpoints[i]);
                if (checkpointDate > today) {
                    progress = (i - 1) / (checkpointsCount - 1) * 100;
                    break;
                }
            }

            return progress;
        }

        const checkpoints = <?php echo json_encode($rows[0]); ?>;
        drawRoadmap('roadmapContainer', Object.values(checkpoints));
    </script>
</body>
</html>
