<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roadmap</title>
    <style>
        /* Styling for the container */
        body {
            padding: 0 50px; /* Added padding on both sides of the screen */
        }

        /* Styling for the roadmap */
        .roadmap {
            position: relative;
            height: 30px; /* Reduced height for the rope */
            width: calc(100% - 100px); /* Adjusted width to accommodate padding */
            margin: 0 auto; /* Center the roadmap */
            background-color: #f2f2f2;
            padding: 20px; /* Added padding inside the roadmap */
        }

        /* Styling for the rope (line) */
        .rope {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            height: 10px; /* Increased thickness for the rope */
            width: 100%;
            background-color: #ccc; /* Default grey color for the rope */
        }

        /* Styling for the blue section of the rope */
        .progress {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            background-color: blue; /* Blue color for the progress */
            z-index: 0; /* Ensure the progress bar is behind the knots */
        }

        /* Styling for the knots (checkpoints) */
        .knot {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            height: 20px;
            width: 20px;
            background-color: #ccc; /* Default color for the knots */
            border-radius: 50%;
            z-index: 1;
        }

        /* Styling for the completed knots */
        .completed {
            background-color: blue; /* Blue color for the completed knots */
        }

        /* Styling for the date labels */
        .date {
            position: absolute;
            bottom: -30px; /* Adjusted position */
            left: 50%;
            transform: translateX(-50%);
            font-size: 12px;
            color: #333; /* Dark color for the date labels */
        }
    </style>
</head>
<body>
    <div>
        <label for="contestId">Enter Contest ID:</label>
        <input type="text" id="contestId" name="contestId">
        <button onclick="fetchRoadmap()">Fetch Roadmap</button>
    </div>

    <div id="roadmapContainer"></div>

    <script>
        function fetchRoadmap() {
            const contestId = document.getElementById('contestId').value.trim();

            if (contestId === '') {
                alert('Please enter a contest ID.');
                return;
            }

            fetch('logic.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=' + contestId,
            })
            .then(response => response.json())
            .then(data => {
                const checkpoints = data[0];
                drawRoadmap('roadmapContainer', Object.values(checkpoints));
            })
            .catch(error => {
                console.error('Error fetching roadmap data:', error);
            });
        }

        function drawRoadmap(containerId, checkpoints) {
            const container = document.getElementById(containerId);

            if (!container) {
                console.error('Container element not found.');
                return;
            }

            const today = new Date();
            const checkpointsCount = checkpoints.length;

            let progressWidth = 0;

            const roadmapHTML = `
                <div class="roadmap">
                    <div class="rope"></div>
                    <div class="progress" style="width: ${progressWidth}%"></div>
                    ${checkpoints.map((checkpoint, index) => {
                        const date = new Date(checkpoint);
                        const progress = index / (checkpointsCount - 1) * 100;
                        const completed = date < today ? 'completed' : '';

                        if (date < today) {
                            progressWidth = progress;
                        }

                        return `
                            <div class="knot ${completed}" style="left: ${progress}%">
                                <span class="date">${formatDate(date)}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;

            container.innerHTML = roadmapHTML;
        }

        function formatDate(date) {
            const options = { month: 'short', day: 'numeric', year: 'numeric' };
            return date.toLocaleDateString('en-US', options);
        }
    </script>
</body>
</html>
