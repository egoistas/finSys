<?php
$db_host = 'localhost';
$db_user = 'root';
$db_password = 'root';
$db_database = 'procurement';

$dbc = mysqli_connect($db_host, $db_user, $db_password, $db_database);
?>